package net.itsrelizc.mcserver.LanguageManager;

import java.util.HashMap;
import java.util.Map;

public class TemporaryRawFunctionStorageForParsing {
    public static Map<String,RawFunction> variables= new HashMap<>();

}
