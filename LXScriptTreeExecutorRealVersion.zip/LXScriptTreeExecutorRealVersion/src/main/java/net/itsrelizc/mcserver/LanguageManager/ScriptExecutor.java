package net.itsrelizc.mcserver.LanguageManager;

import org.apache.logging.log4j.core.script.Script;
import org.bukkit.Bukkit;

import java.util.HashMap;
import java.util.Map;

public class ScriptExecutor {
    public Map<String,Object> globals = new HashMap<>();

    public Map<String,ParsedFunction> funcs;
    public ScriptExecutor(Map<String,ParsedFunction> funcs){
        this.funcs = funcs;
    }
    public void executeMain(){
        Node main = this.funcs.get("main").contents;
        this.execute(main,this.funcs.get("main").args.store);
    }
    public Object execute(Node torun,LocalStorage storage){
        switch(torun.getName()){
            case "operator":
                if(torun.getValue() == "ASSIGN"){
                    if(globals.containsKey((String) torun.getNodebyName("loc").getValue())){
                        globals.put((String) torun.getNodebyName("loc").getValue(),this.execute(torun.getNodebyName("val"),storage));
                    }else{
                        storage.variables.put((String) torun.getNodebyName("loc").getValue(),this.execute(torun.getNodebyName("val"),storage));
                    }
                    return true;
                }else if(torun.getValue() == "print"){
                    StringBuilder result = new StringBuilder();
                    for(Node i:torun.getChildren()){
                        result.append(this.execute(i,storage));
                    }
                    Bukkit.broadcastMessage(result.toString());
                    return true;

                }else if(torun.getValue() == "EXEC"){
                    ParsedFunction wFunc = this.funcs.get((String) torun.getNodebyName("funcName").getValue());
                    return this.execute(wFunc.contents,wFunc.args.store);
                }else{
                    Object side1 = this.execute(torun.getChildren().get(0).getChildren().get(0),storage);
                    Object side2 = this.execute(torun.getChildren().get(1).getChildren().get(0),storage);
                    switch((String) torun.getValue()){

                        case "PLUS":


                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1+(Integer)side2
                                    );
                    }
                }

        }
    }
}
