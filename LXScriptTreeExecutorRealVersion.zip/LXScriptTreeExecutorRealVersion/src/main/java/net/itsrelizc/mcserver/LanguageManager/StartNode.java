package net.itsrelizc.mcserver.LanguageManager;

public class StartNode extends Node{

    public StartNode() {
        super(null, "base");
    }
}
