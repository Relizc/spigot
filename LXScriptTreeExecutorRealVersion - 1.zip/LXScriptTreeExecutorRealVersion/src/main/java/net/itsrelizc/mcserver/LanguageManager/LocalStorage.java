package net.itsrelizc.mcserver.LanguageManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LocalStorage {
    public Map<String,Object> variables = new HashMap<>();

}
