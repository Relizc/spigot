package net.itsrelizc.mcserver.LanguageManager;

import org.apache.logging.log4j.core.script.Script;
import org.bukkit.Bukkit;

import java.sql.Array;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScriptExecutor {
    public Map<String,Object> globals = new HashMap<>();

    public Map<String,ParsedFunction> funcs;
    public ScriptExecutor(Map<String,ParsedFunction> funcs){
        this.funcs = funcs;
    }
    public void executeMain(){


        Node main = this.funcs.get("main").contents;
        for(ParsedFunction i:this.funcs.values()) this.globals.put(i.name,i);
        for(Node i:main.getChildren()){
            this.execute(i,this.funcs.get("main").args.store);
        }
    }
    public Object execute(Node torun,LocalStorage storage){
        switch(torun.getName()){
            case "operator":
                if(torun.getValue() == "ASSIGN"){
                    if(globals.containsKey((String) torun.getNodebyName("loc").getValue())){
                        globals.put((String) torun.getNodebyName("loc").getValue(),this.execute(torun.getNodebyName("val").getChildren().get(0),storage));
                    }else{
                        System.out.println(torun.getNodebyName("val").getChildren().get(0).getValue());
                        storage.variables.put((String) torun.getNodebyName("loc").getValue(),this.execute(torun.getNodebyName("val").getChildren().get(0),storage));
                    }
                    return true;
                }else if(torun.getValue() == "print"){
                    StringBuilder result = new StringBuilder();
                    for(Node i:torun.getChildren()){
                        result.append(this.execute(i,storage));

                    }

                    System.out.println(storage.variables.toString());


                    Bukkit.broadcastMessage("[SERVER]"+result.toString());
                    return true;

                }else if(torun.getValue() == "EXEC"){

                    if(Builtins.funcNames.contains((String) torun.getNodebyName("funcName").getValue())) {
                        String funcName = (String) torun.getNodebyName("funcName").getValue();
                        List<Object> args = new ArrayList<>();
                        for(Node i:torun.getNodeByValue("ARGS").getChildren()){
                            args.add(this.execute(i,storage));
                        }
                        return Builtins.executeBuiltinFunction(args,funcName);



                    }else{

                        ParsedFunction wFunc = (ParsedFunction) this.globals.get((String) torun.getNodebyName("funcName").getValue());
                        List<String> args = wFunc.args.args;

                        System.out.println("VAL"+ torun.getNodeByValue("ARGS").getChildren().get(0).getName());

                        Object[] acceptedArgs = new Object[args.size()];


                        for(Node i:torun.getNodeByValue("ARGS").getChildren()){
                            Integer argId = (Integer) i.getValue();


                            Object content = this.execute(i.getChildren().get(0),storage);

                            wFunc.args.store.variables.put(args.get(argId),content);

                        }


                        return this.execute(wFunc.contents,wFunc.args.store);
                    }
                }else{
                    Object side1 = this.execute(torun.getChildren().get(0).getChildren().get(0),storage);
                    Object side2 = this.execute(torun.getChildren().get(1).getChildren().get(0),storage);
                    switch((String) torun.getValue()){

                        case "PLUS":


                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1+(Integer)side2
                                    );
                        case "MINUS":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer) side1-(Integer)side2
                            );

                        case "MULTIPLY":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1*(Integer)side2
                            );
                        case "DIVIDE":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1/(Integer)side2
                            );
                        case "POWER":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    Math.round((float) Math.pow((Integer) side1,(Integer) side2))

                            );
                        case "BITMOV_LEFT":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1<<(Integer)side2
                            );
                        case "BITMOV_RIGHT":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1>>(Integer)side2
                            );
                        case "OR":
//                            assert side2 instanceof Integer;
//                            assert side1 instanceof Integer;
                            return (
                                    (Integer) side1|(Integer) side2
                            );
                        case "AND":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1&(Integer)side2
                            );
                        case "XOR":
                            assert side2 instanceof Integer;
                            assert side1 instanceof Integer;
                            return (
                                    (Integer)side1^(Integer)side2
                            );
                        case "EQUALS_CHECK":

                            return (
                                    side1==side2
                            );
                        case "UNEQUAL_CHECK":
                            return side1!=side2;
                    }
                }
            case "integer":

                return (Integer) torun.getValue();
            case "string": return (String) torun.getValue();
            case "null":
                if(torun.getValue() == "Parenthesis"){
                    return this.execute(torun.getChildren().get(0),storage);
                }
                break;
            case "UNDEFINED":
                String name = (String) torun.getValue();
                if(!Builtins.funcNames.contains(name)){
                    if(globals.containsKey(name)){
                        return globals.get(name);
                    }else if(storage.variables.containsKey(name)){
                        return storage.variables.get(name);
                    }else{
                        return false;
                    }
                }
                return false;




        }
        return null;
    }
}
