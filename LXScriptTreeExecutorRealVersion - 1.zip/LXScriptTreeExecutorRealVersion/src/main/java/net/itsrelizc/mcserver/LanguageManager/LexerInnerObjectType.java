package net.itsrelizc.mcserver.LanguageManager;

public enum LexerInnerObjectType {
    PRN ,
    WHILE ,
    IF ,
    STARTPARENT ,
    ENDPARENT ,
    STARTCURL ,
    ENDCURL ,
    FUNC ,
    CLASS ,
    CALL ,
    IMPORT ,
    STOPL ,
    COMMA ,
    NEWLINE,
    ASS ;




}
