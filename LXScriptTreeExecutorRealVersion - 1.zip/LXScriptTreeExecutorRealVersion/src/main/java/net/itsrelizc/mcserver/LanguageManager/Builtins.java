package net.itsrelizc.mcserver.LanguageManager;

import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Builtins {
    public static List<String> funcNames = Arrays.asList(
            "execute","getPlayerByName"
    );
    public static Object executeBuiltinFunction(List<Object> args,String funcName){
        switch(funcName){
            case "execute":
                if(args.size() == 1){
                    String cmd = (String) args.get(0);
                    Bukkit.dispatchCommand(Bukkit.getConsoleSender(),cmd);
                    return true;
                }
                return false;
            case "getPlayerByName":
                if(args.size() == 1){
                    String name = (String) args.get(0);
                    return  Bukkit.getPlayer(name);

                }
                return false;

        }
        return null;
    }

}
