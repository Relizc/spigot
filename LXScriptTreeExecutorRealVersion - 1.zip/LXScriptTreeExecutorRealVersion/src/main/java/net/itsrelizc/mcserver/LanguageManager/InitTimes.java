package net.itsrelizc.mcserver.LanguageManager;

public class InitTimes {
    public static Integer initThing = 0;
}
