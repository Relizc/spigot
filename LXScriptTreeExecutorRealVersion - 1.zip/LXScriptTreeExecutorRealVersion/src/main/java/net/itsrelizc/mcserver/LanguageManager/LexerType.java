package net.itsrelizc.mcserver.LanguageManager;

public enum LexerType {
    SYN(),
    ID(),
    SYM(),
    STR(),
    EXP(),
    ASS(),
    FUNC(),
    IF(),
    LOOP(),
    DEFS(),
    UNKNOWN();

}
